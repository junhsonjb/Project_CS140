package project;

public interface HaltCallback {
	void halt();
}